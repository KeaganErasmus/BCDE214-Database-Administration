-- Write Your Code here
USE [Vaccinations];


-- Testing data
--DELETE FROM Place
--SELECT * FROM Place
--EXEC bulkLoadVaccinators @fileName = 'C:\Temp\Vaccine2021\Sites.csv'
--SELECT * FROM Place