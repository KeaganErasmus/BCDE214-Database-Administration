In this iteration I created the backup for my database, I also explained how I created it and how you could restore the database
I also created two roles for my database a Developer role and a Worker role, I explained how I created each role and what each role
was able to do.
I also created my Performance Review.